package database;

public class DBScheme {
    static String USER= "manuelcorrecher";
    static String PASS= "unirDAM";
}
