package database;

public interface SchemaDB {

    String DATABASE = "usuariosAD";
    String TAB_USER = "usuarios";
    String COL_NAME = "nombre";
    String COL_MAIL = "correo";
    String COL_PASS = "password";
    String COL_ID = "id";

}
