package com.example.ExamenAD2Ev.repository;

import com.example.ExamenAD2Ev.model.Aula;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AulaRepository extends JpaRepository<Aula,Integer> {
}
