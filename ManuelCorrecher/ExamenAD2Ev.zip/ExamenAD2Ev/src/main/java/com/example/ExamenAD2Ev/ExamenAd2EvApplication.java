package com.example.ExamenAD2Ev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenAd2EvApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenAd2EvApplication.class, args);
	}

}
