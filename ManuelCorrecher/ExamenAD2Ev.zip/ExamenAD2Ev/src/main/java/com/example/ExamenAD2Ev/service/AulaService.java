package com.example.ExamenAD2Ev.service;

import com.example.ExamenAD2Ev.model.Aula;

import java.util.List;

public interface AulaService {

    List<Aula> getAllAulasMas30();
}
