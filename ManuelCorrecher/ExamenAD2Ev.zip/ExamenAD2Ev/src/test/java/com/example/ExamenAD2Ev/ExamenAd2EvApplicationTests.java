package com.example.ExamenAD2Ev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenAd2EvApplicationTests {

	@Test
	void contextLoads() {
	}

}
